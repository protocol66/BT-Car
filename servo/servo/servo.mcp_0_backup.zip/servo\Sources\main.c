#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "main_asm.h"

int init_servo(const unsigned short);
int set_servo(const unsigned short, const unsigned short);
void reset_all_servos();
void stop_all_servos();

//initializes 2 pwms into 1 16bit pwm
//valid servo numbers 1,3,5,7
int init_servo(const unsigned short servo_num)  {

    switch (servo_num)
    {
        case 1:
            PWMPER0 = 0xEA;     // 8 bit + 8bit = 16bit
            PWMPER1 = 0x60;     // 3MHz / 60,000 = 20ms
            set_servo(1, 50);      //set servo to 50 percent
            break;

        case 3:
            PWMPER2 = 0xEA;
            PWMPER3 = 0x60;
            set_servo(3, 50);
            break;

        case 5:
            PWMPER4 = 0xEA;
            PWMPER5 = 0x60;
            set_servo(5, 50);
            break;

        case 7:
            PWMPER6 = 0xEA;
            PWMPER7 = 0x60;
            set_servo(7, 50);
            break;

        default:
            return 1;
            break;
    }

    PWME |= servo_num;    //enable pwm 1, pwm 0 not use because they are concatenated
    PWMPOL |= servo_num;  //set duty cycle = on time
    PWMCLK |= servo_num;  //set pwm 1 to use clock A, because reasons...
    PWMPRCLK = 0x33;         //set prescaler for both clock A and B to 24/8 = 3MHz
    PWMCAE = 0x0;            //set left allign
    PWMCTL |= 0x10;          //concatinate pwm 0 and 1 to 16 bit pwm

    return 0;
}

//servo_num number of servo, valid servo numbers 1,3,5,7
int set_servo(const unsigned short servo_num, const unsigned short pos_input)  {
    unsigned short pwm = (3000 * (pos_input/100) + 3000); // 3000 = 1ms,

    switch (servo_num)
    {
        case 1:
            PWMDTY01 = pwm;
            break;

        case 3:
            PWMDTY23 = pwm;
            break;

        case 5:
            PWMDTY45 = pwm;
            break;

        case 7:
            PWMDTY67 = pwm;
            break;

        default:
            return 1;
            break;
    }

    return 0;

}

//disables all pwm
void stop_all_servos()  {
    PWMPER0 = 0x00;
    PWMPER1 = 0x00;
    PWMPER2 = 0x00;
    PWMPER3 = 0x00;
    PWMPER4 = 0x00;
    PWMPER5 = 0x00;
    PWMPER6 = 0x00;
    PWMPER7 = 0x00;

    PWMDTY0 = 0x00;
    PWMDTY1 = 0x00;
    PWMDTY2 = 0x00;
    PWMDTY3 = 0x00;
    PWMDTY4 = 0x00;
    PWMDTY5 = 0x00;
    PWMDTY6 = 0x00;
    PWMDTY7 = 0x00;
}

//disables all pwm and resets the values
void reset_all_servos() {
    PWME = 0x00;
    PWMPOL = 0x00;
    PWMCLK = 0x00;
    PWMPRCLK = 0x00;
    PWMCAE = 0x00;
    PWMCTL = 0x00;
    stop_all_servos();
}

void main(void) {
  /* put your own code here */
  
  //DDRP = 0xFF;
  //DDRJ = 0xFF;
  //PTJ = 0x00;
  //PTP = 0x00;
  
  
  //PWME = 0x01;    //enable pwm 1, pwm 0 not use because they are concatenated
  //PWMPOL = 0x01;  //set duty cycle = on time
  //PWMCLK = 0x01;  //set pwm 1 to use clock A, because reasons...
  //PWMPRCLK = 0x33;         //set prescaler for both clock A and B to 24/8 = 3MHz
  //PWMCAE = 0x0;            //set left allign
  //PWMCTL = 0x10;
  //PWMPER01 = 60000;
  //PWMDTY01 = 3000;
  
  PWM_Init(120,0,0,60);
  
  //init_servo(1);
  //set_servo(1,30);

	EnableInterrupts;
	
	while(1)  {
	    //int i =0;
	    //for(i = 0; i < 6000;i++);
	    //PTP = 0x01;
	    //for(i = 0; i < 6000;i++);
	    //PTP = 0x00;
	}


  for(;;) {
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
